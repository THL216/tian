<?php
namespace app\models;

use yii\db\ActiveRecord;

class User extends ActiveRecord{

}