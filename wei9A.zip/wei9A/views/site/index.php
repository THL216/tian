<!--开始：以下内容则可删除，仅为素材引用参考-->
        <h1 style="color:red;font-size:20px;font-weight:bold;text-align:center;">Example/Explanation</h1>
        <p style="color:red;font-size:16px;font-weight:bold;text-align:center;">这里是相关常用性样式预设，具体根据内容版块调整，列表添加字段注意考虑笔记本屏幕显示；<br/>此页面仅为样式参考，程序对接可移除，具体布局根据项目内容而定<br/>注意保留rt_content.parent</p>
        <section>
            <h2><strong style="color:grey;">常用按钮（水平块元素，无区域限制）</strong></h2>
            <a class="link_btn" id="loading">点击加载</a>
            <button class="link_btn" id="showPopTxt">测试弹出框</button>
            <input type="button" value="按钮input" class="link_btn"/>
        </section>
        <section>
            <h2><strong style="color:grey;">表单样式（组合）</strong></h2>
            <input type="text" class="textbox" placeholder="默认宽度..."/>
            <input type="text" class="textbox textbox_295" placeholder="class=295px..."/>
            <input type="text" class="textbox textbox_225" placeholder="class=225px..."/>
            <select class="select">
                <option>下拉菜单</option>
                <option>菜单1</option>
            </select>
            <input type="button" value="组合按钮" class="group_btn"/>
        </section>
<!--结束：以下内容则可删除，仅为素材引用参考-->