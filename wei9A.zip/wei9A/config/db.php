<?php
					return [
						'class' => 'yii\db\Connection',
						'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=wei9a',
						'username' => 'root',
						'password' => 'root',
						'charset' => 'utf8',
						'tablePrefix' => 'wei_',   //加入前缀名称
					];