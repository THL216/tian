<?php
namespace app\models;

use yii\db\ActiveRecord;

class Publicnum extends ActiveRecord{

}